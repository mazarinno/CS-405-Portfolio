# Numeric-Overflow
Preventing numeric overflow in CPP for CS405

![no1](https://user-images.githubusercontent.com/15134446/222672584-da35a666-4774-47d6-a835-e36f62321b42.PNG)
![no2](https://user-images.githubusercontent.com/15134446/222672588-d265eaf6-0c55-47c2-91f2-701dab49106f.PNG)
